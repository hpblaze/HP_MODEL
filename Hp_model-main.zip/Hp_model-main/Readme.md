It has code for mmodeling 50*20*20 (nodes) sand sample with basic simulations 
